Gedebuk adalah sebuah aplikasi yang berguna bagi pecinta novel. 
Para pecinta novel sering kali mengalami kesulitan seperti mencari 
buku yang ingin dibeli, ingin mengetahui isi dari buku terlebih 
dahulu, dan buku yang sudah pernah dibaca hanya tersimpan di dalam 
lemari, kebanyakan mereka merasa buku tersebut sudah tidak perlu 
dibaca lagi sehingga kurang  bermanfaat untuk disimpan. 
Gedebuk memiliki fitur-fitur yang dapat mengatasi masalah-masalah 
tersebut seperti membaca deskripsi atau prolog dari sebuah novel 
yang sudah terbit maupun yang akan terbit. Selain itu, gedebuk juga 
memiliki fitur untuk menjual novel yang sudah pernah dibaca dimana 
terdapat deskripsi sudah berapa banyak buku tersebut dibaca atau 
di beli orang lain. Tidak lupa gedebuk juga akan menampilkan 
novel-novel yang akan diterbitkan oleh penulis favorit mereka. 